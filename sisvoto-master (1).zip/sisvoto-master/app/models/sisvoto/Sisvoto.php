<?php

namespace App\models\sisvoto;

use Illuminate\Database\Eloquent\Model;

class Sisvoto extends Model
{
    //
}
