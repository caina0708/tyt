
##  SisVoto

SisVoto, trata-se de um sistema de votação para eleições diversas, desenvolvido apenas como estudo acadêmico, o mesmo não está completo, sendo que faltam alguns módulos para ser desenvolvidos.

## Licença

SisVoto é open-sourced, software sobre a licença [MIT license](http://opensource.org/licenses/MIT).
