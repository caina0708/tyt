$(document).ready(function(){
    $('.cpf-mascara').mask('000.000.000-00');
});